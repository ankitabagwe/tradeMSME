package com.example.hemant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HemantApplicationTests {

	@Test
	void contextLoads() {
	}

}
