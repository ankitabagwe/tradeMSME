package repository;

public interface chat {

}
