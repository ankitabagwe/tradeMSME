package repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import entity.buisnessdetailsent;
import entity.prodentity_folders;
import entity.product_base64;

@Repository
public interface prodrepo_folder extends JpaRepository<prodentity_folders, Integer>{

//	List<prodentity_folders> findByProductNameContainingIgnoreCase(String productName);
	
	  List<prodentity_folders> findBymobileNumber(String mobileNumber);
	
	  
	    List<prodentity_folders> findByProductNameContainingIgnoreCase(String productName);

	  @Query("SELECT p FROM prodentity_folders p WHERE p.productName LIKE %:name%")
	    List<prodentity_folders> findByProductName(@Param("name") String name);
	    
	    List<prodentity_folders> findByProductNameContainingIgnoreCaseAndProductdescriptionContainingIgnoreCase(String productName, String city);

	    List<prodentity_folders> findByProductdescriptionContainingIgnoreCase(String city);

	    @Query(value = "SELECT * FROM prodentity_folders ORDER BY RAND() LIMIT :limit", nativeQuery = true)
	    List<prodentity_folders> findRandomProducts(@Param("limit") int limit);
	    
//	    prodentity_folders findByProductName(String productName);
}
