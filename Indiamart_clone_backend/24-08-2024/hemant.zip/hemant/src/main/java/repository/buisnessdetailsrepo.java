package repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import entity.BuyerProfile;
import entity.buisnessdetailsent;

@Repository
public interface buisnessdetailsrepo extends JpaRepository<buisnessdetailsent, String>{

	 boolean existsBymobilenumber(String mobilenumber);
	
	 buisnessdetailsent findBymobilenumber(String mobilenumber);
}
