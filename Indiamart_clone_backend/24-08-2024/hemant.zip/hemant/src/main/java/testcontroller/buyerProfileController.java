package testcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import entity.BuyerProfile;
import service.buyerprofileservice;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class buyerProfileController {

	@Autowired
	private buyerprofileservice buyerprofservice;
	
	@PostMapping("/userprofile")
	@CrossOrigin(origins = "http://localhost:4200")
	 public ResponseEntity<String> registerBuyer(@RequestBody BuyerProfile profile) {
		System.out.println(profile);
		buyerprofservice.saveProfile(profile);
	        return ResponseEntity.ok("Profile saved successfully!");
	    }
	
	
	@GetMapping("/details/{mobileNumber}")
	public ResponseEntity<?> getUserDetailsByMobileNumber(@PathVariable String mobileNumber) {
		BuyerProfile user = buyerprofservice.getUserByMobileNumber(mobileNumber);
        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }
    }
	
	
	
	
}
