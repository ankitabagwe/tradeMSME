package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.BuyerProfile;
import repository.Buyerprofilerepo;

@Service
public class buyerprofileservice {

	@Autowired
	private Buyerprofilerepo buyerprofilerepo;
	
	public BuyerProfile saveProfile(BuyerProfile profile) {
	
		return buyerprofilerepo.save(profile);
		
	}
	
	public BuyerProfile getUserByMobileNumber(String mobileNumber) {
        return buyerprofilerepo.findByMobileNumber(mobileNumber);
    }
	
}
