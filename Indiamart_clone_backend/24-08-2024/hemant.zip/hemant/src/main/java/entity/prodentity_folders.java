package entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class prodentity_folders {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int id;
	private String productName;
	private String Price;
	private String productdescription;
	private String filepath; 
	private String youtubeLink;
	private String pdffilepath;
	private String shippingOption;
	private String taxOption;
	@Column(name = "mobile_number",nullable = false)
	 private String mobileNumber;
	
	 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getproductName() {
		return productName;
	}
	public void setproductName(String productName) {
		this.productName = productName;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		Price = price;
	}
	public String getProductdescription() {
		return productdescription;
	}
	public void setProductdescription(String productdescription) {
		this.productdescription = productdescription;
	}
	public String getFilepath() {
		return filepath;
	}
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	 public String getYoutubeLink() {
		return youtubeLink;
	}
	
	public void setYoutubeLink(String youtubeLink) {
		this.youtubeLink = youtubeLink;
	}
	public String getpdffilepath() {
		return pdffilepath;
	}
	public void setpdffilepath(String pdffilepath) {
		this.pdffilepath = pdffilepath;
	}
	public String getShippingOption() {
		return shippingOption;
	}
	public void setShippingOption(String shippingOption) {
		this.shippingOption = shippingOption;
	}
	public String getTaxOption() {
		return taxOption;
	}
	public void setTaxOption(String taxOption) {
		this.taxOption = taxOption;
	}

	 
	
	@Override
	public String toString() {
		return "prodentity_folders [id=" + id + ", productName=" + productName + ", Price=" + Price
				+ ", productdescription=" + productdescription + ", filepath=" + filepath + ", mobileNumber="
				+ mobileNumber + ", youtubeLink=" + youtubeLink + ", pdffilepath=" + pdffilepath + ", shippingOption="
				+ shippingOption + ", taxOption=" + taxOption + "]";
	}
	
	
	
	public prodentity_folders(int id, String productName, String price, String productdescription, String filepath,
			String mobileNumber, String youtubeLink, String pdfFile, String shippingOption, String taxOption) {
		super();
		this.id = id;
		this.productName = productName;
		Price = price;
		this.productdescription = productdescription;
		this.filepath = filepath;
		this.mobileNumber = mobileNumber;
		this.youtubeLink = youtubeLink;
		this.pdffilepath = pdffilepath;
		this.shippingOption = shippingOption;
		this.taxOption = taxOption;
	}
	
	

	public prodentity_folders() {
		super();
		// TODO Auto-generated constructor stub
	}
 
	
}
