package entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class BuyerProfile {
	@Id
    @Column(nullable = false, length = 10, unique = true)
    private String mobileNumber; // Primary key

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false, length = 6)
    private String pincode;

    @Column(nullable = false)
    private String city;

    @Column(nullable = false)
    private String companyName;

    @Column(nullable = false)
    private String gstin;

    @Column(nullable = false)
    private String pan;

    @Column(nullable = false)
    private String ifsccode;

    @Column(nullable = false)
    private String accountNumber;

    @Column(nullable = false)
    private String bankName;

    @Column(nullable = false)
    private String accountType;

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getpincode() {
		return pincode;
	}

	public void setpincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getgstin() {
		return gstin;
	}

	public void setgstin(String gstin) {
		this.gstin = gstin;
	}

	public String getpan() {
		return pan;
	}

	public void setpan(String pan) {
		this.pan = pan;
	}

	public String getifsccode() {
		return ifsccode;
	}

	public void setifsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	@Override
	public String toString() {
		return "BuyerProfile [mobileNumber=" + mobileNumber + ", name=" + name + ", email=" + email + ", pincode="
				+ pincode + ", city=" + city + ", companyName=" + companyName + ", gstin=" + gstin + ", pan=" + pan
				+ ", ifsccode=" + ifsccode + ", accountNumber=" + accountNumber + ", bankName=" + bankName
				+ ", accountType=" + accountType + "]";
	}

	public BuyerProfile(String mobileNumber, String name, String email, String pincode, String city, String companyName,
			String gstin, String pan, String ifsccode, String accountNumber, String bankName, String accountType) {
		super();
		this.mobileNumber = mobileNumber;
		this.name = name;
		this.email = email;
		this.pincode = pincode;
		this.city = city;
		this.companyName = companyName;
		this.gstin = gstin;
		this.pan = pan;
		this.ifsccode = ifsccode;
		this.accountNumber = accountNumber;
		this.bankName = bankName;
		this.accountType = accountType;
	}

	public BuyerProfile() {
		super();
		// TODO Auto-generated constructor stub
	}
	
    
}
