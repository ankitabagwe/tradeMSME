package entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;


public class product_base64 {
  
	
	 private int id;
	 private String productName;
	 private String price;
	 private String productDescription;
	 private String file;
	 @Column(nullable = false,name = "mobile_number")
	 private String mobileNumber;
	 private String youtubeLink;
	 private String pdfFile;
	 private String shippingOption;
	 private String taxOption;
	 
	 
	
	public String getYoutubeLink() {
		return youtubeLink;
	}
	public void setYoutubeLink(String youtubeLink) {
		this.youtubeLink = youtubeLink;
	}
	public String getPdfFile() {
		return pdfFile;
	}
	public void setPdfFile(String pdfFile) {
		this.pdfFile = pdfFile;
	}
	public String getShippingOption() {
		return shippingOption;
	}
	public void setShippingOption(String shippingOption) {
		this.shippingOption = shippingOption;
	}
	public String getTaxOption() {
		return taxOption;
	}
	public void setTaxOption(String taxOption) {
		this.taxOption = taxOption;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	public product_base64(int id, String productName, String price, String productDescription, String file,
			String mobileNumber, String youtubeLink, String pdfFile, String shippingOption, String taxOption) {
		super();
		this.id = id;
		this.productName = productName;
		this.price = price;
		this.productDescription = productDescription;
		this.file = file;
		this.mobileNumber = mobileNumber;
		this.youtubeLink = youtubeLink;
		this.pdfFile = pdfFile;
		this.shippingOption = shippingOption;
		this.taxOption = taxOption;
	}
	
	
	@Override
	public String toString() {
		return "product_base64 [id=" + id + ", productName=" + productName + ", price=" + price
				+ ", productDescription=" + productDescription + ", file=" + file + ", mobileNumber=" + mobileNumber
				+ ", youtubeLink=" + youtubeLink + ", pdfFile=" + pdfFile + ", shippingOption=" + shippingOption
				+ ", taxOption=" + taxOption + "]";
	}
	
	
	public product_base64() {
		super();
		// TODO Auto-generated constructor stub
	}
	 
	 
	 
	 
//	public product_base64(String productName, String price, String productDescription, String file,
//			String mobileNumber) {
//		super();
//		this.productName = productName;
//		this.price = price;
//		this.productDescription = productDescription;
//		this.file = file;
//		this.mobileNumber = mobileNumber;
//	}
//	public String getMobileNumber() {
//		return mobileNumber;
//	}
//	public void setMobileNumber(String mobileNumber) {
//		this.mobileNumber = mobileNumber;
//	}
//	public String getProductName() {
//		return productName;
//	}
//	public void setProductName(String productName) {
//		this.productName = productName;
//	}
//	public String getPrice() {
//		return price;
//	}
//	public void setPrice(String price) {
//		this.price = price;
//	}
//	public String getProductDescription() {
//		return productDescription;
//	}
//	public void setProductDescription(String productDescription) {
//		this.productDescription = productDescription;
//	}
//	public String getFile() {
//		return file;
//	}
//	public void setFile(String file) {
//		this.file = file;
//	}
//	@Override
//	public String toString() {
//		return "product_base64 [productName=" + productName + ", price=" + price + ", productDescription="
//				+ productDescription + ", file=" + file + ", mobileNumber=" + mobileNumber + "]";
//	}
//	public product_base64(String productName, String price, String productDescription, String file) {
//		super();
//		this.productName = productName;
//		this.price = price;
//		this.productDescription = productDescription;
//		this.file = file;
//	}
//	public product_base64() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//	    
//	    
	 
}
